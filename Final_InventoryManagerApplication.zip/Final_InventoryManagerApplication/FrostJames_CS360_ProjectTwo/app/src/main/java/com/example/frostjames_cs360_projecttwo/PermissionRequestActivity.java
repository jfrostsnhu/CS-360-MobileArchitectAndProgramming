package com.example.frostjames_cs360_projecttwo;

import android.app.Activity;

public class PermissionRequestActivity extends Activity {
}
