package com.example.inventorymanagerapplication;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

// This class facilitates the low stock alert notifications channel used for POST notifications

public class Notifications extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    // Create the channel and set options for the POST Notifications
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence notificationTitle = getString(R.string.low_stock_channel_name);
            String notificationDesc = getString(R.string.low_stock_channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel("low_stock_alerts", notificationTitle, importance);
            channel.setDescription(notificationDesc);
            channel.enableLights(true); // Tell the device to light up
            channel.enableVibration(true); // Tell the device to vibrate

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}
