package com.example.inventorymanagerapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

//     This class facilitates maintenance of the inventory list

public class InventoryFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private ListView itemsListView;
    private SimpleCursorAdapter itemsCursoradapter;
    private EditText searchItems;
    private ImageButton logoutButton;
    private ImageButton addItemButton;
    public static final String SHARED_PREFS = "Shared_Prefs";
    public int isAdmin;
    SharedPreferences sharedPreferences;

    // Inflate the layout and initialize the views and assets, set addItem and logout onClick Listeners
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);
        initViews(view);
        setupListViewAdapter();
        new LoadItemsTask().execute(); // Execute LoadItemsTask AsyncTask when the view is launched

        isAdmin = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE).getInt("is_admin", 0);

        // Setup the text watcher for the search input field
        searchItems.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Execute the filter task as text changes asynchronously
                new FilterItemsTask().execute(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
        // Only call showAddItemDialog() if isAdmin == 1
        addItemButton.setOnClickListener(v -> showAddItemDialog());
        // Set onClick listener for logout
        logoutButton.setOnClickListener(v -> logoutUser());

        return view;
    }

    // Initialize variables used for the UI and instantiate dbHelper object
    private void initViews(View view) {
        itemsListView = view.findViewById(R.id.items_list_view);
        searchItems = view.findViewById(R.id.search_items);
        logoutButton = view.findViewById(R.id.logoutIF);
        addItemButton = view.findViewById(R.id.addItemIF);
        dbHelper = new DatabaseHelper(getActivity());
    }

    // Set the listView adapter and data bindings for items_list_view
    private void setupListViewAdapter() {
        itemsCursoradapter = new SimpleCursorAdapter(
                getActivity(), R.layout.item_list_item, null,
                new String[]{"skuno", "description", "quantity", "_id"},
                new int[]{R.id.sku_no_IF, R.id.description_IF, R.id.quantity_IF, R.id.edit_item},
                0);

        itemsCursoradapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
            // Binding the data to the view
            @Override
            public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                if (view instanceof ImageButton) {
                    ImageButton editItemButton = (ImageButton) view;

                    int itemIdIndex = cursor.getColumnIndex("_id");
                    if (itemIdIndex == -1) {
                        return false; // In case of IndexOutOfBoundsException
                    }
                    int itemId = cursor.getInt(itemIdIndex);

                    int quantityIndex = cursor.getColumnIndex("quantity");
                    if (quantityIndex == -1) {
                        return false; // In case of IndexOutOfBoundsException TODO: Combine if time permits
                    }
                    int quantity = cursor.getInt(quantityIndex);
                    // Set onClick Listener for edit item button
                    editItemButton.setOnClickListener(v -> showEditItemDialog(quantity, itemId));
                    return true;
                }
                return false;
            }
        });
        // Set the adapter with the bound objects and data
        itemsListView.setAdapter(itemsCursoradapter);
    }

    // Load the items_list_view asynchronously
    private class LoadItemsTask extends AsyncTask<Void, Void, Cursor> {
        @Override
        protected Cursor doInBackground(Void... voids) {
            return dbHelper.getAllItems();
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            itemsCursoradapter.changeCursor(cursor);
            itemsCursoradapter.notifyDataSetChanged();
        }
    }

    // Load the items_list_view using search filters asynchronously
    private class FilterItemsTask extends AsyncTask<String, Void, Cursor> {
        @Override
        protected Cursor doInBackground(String... strings) {
            return dbHelper.getFilteredItems(strings[0]);
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            Cursor oldCursor = itemsCursoradapter.swapCursor(cursor);  // Swap and get old cursor
            itemsCursoradapter.notifyDataSetChanged();
            if (oldCursor != null) {
                oldCursor.close();  // Close the old cursor to prevent memory leaks
            }
        }
    }

    // Log the user out, Update SharedPreferences file, Return to LoginActivity
    private void logoutUser() {
        // Clear session data or any other necessary cleanup
        sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("is_admin");
        editor.putBoolean("IsLoggedIn", false);
        editor.apply();

        // Redirect to LoginActivity
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        getActivity().finish();
    }

    /*  Inflate the edit_item dialog and initialize assets then update quantities         */
    /*                     or deletion if permissions allow                               */
    private void showEditItemDialog(int quantity, int itemId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_item, null);
        EditText editQtyText = dialogView.findViewById(R.id.editQuantityEI);
        ImageButton decrementQtyButton = dialogView.findViewById(R.id.btnMinusEI);
        ImageButton incrementQtyButton = dialogView.findViewById(R.id.btnPlusEI);
        Button deleteItemButton = dialogView.findViewById(R.id.btnDeleteItemEI);
        // Fill the Quantity value from cursor
        editQtyText.setText(String.valueOf(quantity));
        // Set onClick listener to decrement 1 quantity in the field
        decrementQtyButton.setOnClickListener(v -> {
            int currentQty = Integer.parseInt(editQtyText.getText().toString());
            if (currentQty > 0) {
                editQtyText.setText(String.valueOf(currentQty - 1));
            }
        });
        // Set onClick listener to increment 1 quantity in the field
        incrementQtyButton.setOnClickListener(v -> {
            int currentQuantity = Integer.parseInt(editQtyText.getText().toString());
            editQtyText.setText(String.valueOf(currentQuantity + 1));
        });
        // Create the dialog and update the quantity on save or dismiss on cancel
        AlertDialog dialog = builder.setView(dialogView)
                .setPositiveButton("Save", (dialogInterface, which) -> {
                    int newQuantity = Integer.parseInt(editQtyText.getText().toString());
                    updateQuantity(itemId, newQuantity);
                })
                .setNegativeButton("Cancel", (dialogInterface, which) -> dialogInterface.dismiss())
                .create();

        dialog.show();
        // Set onClick listener for delete item button, only allow if isAdmin == 1
        deleteItemButton.setOnClickListener(v -> {
            if (isAdmin == 1) {
                showDeleteConfirmationDialog(itemId, dialog);
            } else {
                Toast.makeText(getActivity(), "Must be an Admin", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Create the delete item dialog to confirm deletion of item
    private void showDeleteConfirmationDialog(int itemId, AlertDialog editDialog) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirm Delete");
        builder.setMessage("Are you sure you want to delete this item?");
        builder.setPositiveButton("Yes", (dialog, which) -> {
            deleteItem(itemId); // Call deleteItem on confirmation
            editDialog.dismiss();  // Dismiss the edit dialog if item is deleted
            triggerInventoryCheck(); // Update notifications list asynchronously
        });
        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());  // Dismiss dialog
        builder.create().show();
    }

    // Delete the item and inform the user of result
    private void deleteItem(int itemId) {
        if (dbHelper.deleteItem(itemId)) {
            Toast.makeText(getActivity(), "Item deleted successfully", Toast.LENGTH_SHORT).show();
            new LoadItemsTask().execute();  // Refresh the list to remove the deleted item asynchronously
        } else {
            Toast.makeText(getActivity(), "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
    }

    // Update the quantity in items with the new quantity from the edit_item dialog
    private void updateQuantity(int itemId, int newQuantity) {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        dbHelper.updateQuantity(itemId, newQuantity);
        triggerInventoryCheck(); // Update notifications list asynchronously
        new LoadItemsTask().execute(); // Refresh the list to update the quantity of the item asynchronously
    }

    // Create add_item dialog, inflate the layout, initialize assets, and add an item with data from the view
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.add_item, null);
        final EditText addSkuNoText = dialogView.findViewById(R.id.editTextSkunoAI);
        final EditText addDescText = dialogView.findViewById(R.id.editTextDescriptionAI);
        final EditText addQuantityText = dialogView.findViewById(R.id.editTextQuantityAI);

        builder.setView(dialogView)
                .setPositiveButton("Save", null) // Null here to override the default close behavior
                .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

        AlertDialog dialog = builder.create();
        dialog.show();

        Button positiveButton = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
        // Set onClick listener for validating fields on save
        positiveButton.setOnClickListener(v -> {
            String skuNo = addSkuNoText.getText().toString().trim();
            String description = addDescText.getText().toString().trim();
            String quantityStr = addQuantityText.getText().toString().trim();
            int quantity;
            // Sku cant be empty
            if (skuNo.isEmpty()) {
                Toast.makeText(getActivity(), "You must add a SKU", Toast.LENGTH_SHORT).show();
                return; // Do not dismiss dialog
            }
            // Description cant be empty
            if (description.isEmpty()) {
                Toast.makeText(getActivity(), "You must add a description", Toast.LENGTH_SHORT).show();
                return; // Do not dismiss dialog
            }
            // Quantity cant be empty
            if (quantityStr.isEmpty()) {
                Toast.makeText(getActivity(), "Quantity cannot be empty", Toast.LENGTH_SHORT).show();
                return; // Do not dismiss dialog
            }
            try {
                // Quantity must be a number
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getActivity(), "Invalid quantity", Toast.LENGTH_SHORT).show();
                return;
            }
            // Add item and toast results
            long result = dbHelper.addItem(skuNo, description, quantity);
            if (result == -1) {
                Toast.makeText(getActivity(), "This item already exists", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Item added successfully", Toast.LENGTH_SHORT).show();
                dialog.dismiss(); // Only dismiss if everything is successful
                new LoadItemsTask().execute(); // Refresh the items list asynchronously
                triggerInventoryCheck(); // Update notifications list asynchronously
            }
        });
    }

    // One-time work request to refresh the notifications list based on quantity updates and new items added
    private void triggerInventoryCheck() {
        OneTimeWorkRequest inventoryCheckRequest = new OneTimeWorkRequest.Builder(InventoryCheckWorker.class)
                .build();
        // queue the worker job
        WorkManager.getInstance(getContext()).enqueue(inventoryCheckRequest);
    }
}
