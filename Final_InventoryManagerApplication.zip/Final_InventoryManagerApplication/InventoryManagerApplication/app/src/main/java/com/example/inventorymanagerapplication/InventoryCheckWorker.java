package com.example.inventorymanagerapplication;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/*   This class facilitates maintenance of the notifications list    */
/*            and posting of notifications to the device             */

public class InventoryCheckWorker extends Worker {

    private DatabaseHelper dbHelper;
    public static final String SHARED_PREFS = "Shared_Prefs";

    // Initialize the worker and dbHelper objects
    public InventoryCheckWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        dbHelper = new DatabaseHelper(context);
    }

    // doWork executes the queued task checkInventory() and returns a Result type
    @NonNull
    @Override
    public Result doWork() {
        checkInventory();
        return Result.success(); // TODO: Handle failures?
    }

    // Check for items to be added or removed from notifications
    private void checkInventory() {
        Cursor lowStockItems = dbHelper.getLowStockItems(5); // Set threshold for getLowStockItems in dbHelper
        try {
            int skuNoIndex = lowStockItems.getColumnIndex("skuno");
            int quantityIndex = lowStockItems.getColumnIndex("quantity");
            if (skuNoIndex == -1 || quantityIndex == -1) {
                return; // In case of IndexOutOfBoundsException
            }
            // Loop through lowStockItems to check if it already exists
            while (lowStockItems.moveToNext()) {
                String skuNo = lowStockItems.getString(skuNoIndex);
                int quantity = lowStockItems.getInt(quantityIndex);
                if (!dbHelper.notificationExists(skuNo, quantity)) { // If record does not exist
                    dbHelper.addNotification(skuNo, quantity); // Insert the record
                    postNotification(skuNo, quantity); // Send POST notification
                }
            }
        } finally {
            if (lowStockItems != null) {
                lowStockItems.close(); // Close the cursor when finished
            }
        }

        // Remove notifications for items that are no longer low in stock
        Cursor allNotifications = dbHelper.getAllNotifications(); // Get list of notifications into a cursor
        try {
            int skuNoIndex = allNotifications.getColumnIndex("skuno");
            if (skuNoIndex == -1) {
                return; // In case of IndexOutOfBoundsException
            }
            // Loop through notifications list and remove skuNo if quantity > 5 or no longer exist
            while (allNotifications.moveToNext()) {
                String skuNo = allNotifications.getString(skuNoIndex);
                int currentQuantity = dbHelper.lowStockRecheck(skuNo);
                if (currentQuantity > 5 || currentQuantity == -1)  {
                    dbHelper.removeNotification(skuNo);
                }
            }
        } finally {
            if (allNotifications != null) {
                allNotifications.close(); // Close the cursor when finished
            }
        }
    }

    /*       Suppressed POST Permission warning since it is handled in PermissionsRequestActivity      */
    /*    If notifications permission is granted generate a low_stock_alert with NotificationManager   */
    /*                    POST Notifications were used to simulate SMS Notifications                   */
    @SuppressLint("MissingPermission")
    private void postNotification(String skuNo, int quantity) {
        if (hasSmsPermission()) {  // Check if permissions are granted before posting a notification
            String channelId = "low_stock_alerts";

            // Create an Intent for the MainActivity
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            // Instantiate a pending intent for interaction with the notification and updated it if intent changed
            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            // Build a low_stock_alert notification with the skuNo and quantity
            NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), channelId)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("Low Stock Alert!")
                    .setContentText("SKU: " + skuNo + ", Quantity: " + quantity)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentIntent(pendingIntent) // Pending intent for handling entrance from click
                    .setAutoCancel(true);  // Notification will disappear after click

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());
            notificationManager.notify(1, builder.build());
        }
    }

    // Check the SharedPreferences file if sms permissions were granted
    private boolean hasSmsPermission() {
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean("sms_permission_granted", false);
    }
}
