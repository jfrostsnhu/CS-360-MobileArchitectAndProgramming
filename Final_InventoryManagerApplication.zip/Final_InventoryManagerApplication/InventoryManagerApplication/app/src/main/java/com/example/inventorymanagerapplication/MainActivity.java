package com.example.inventorymanagerapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Constraints;
import java.util.concurrent.TimeUnit;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/*     This class facilitates creation of the views        */
/*      the database, and schedules the worker job         */

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private DatabaseHelper dbHelper;  // Reference to dbHelper for database operations
    public static final String SHARED_PREFS = "Shared_Prefs";

    // Setup the view and create the database
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the database helper and setup the database in the background
        dbHelper = new DatabaseHelper(this);
        new SetupDatabaseTask().execute();

        if (!isLoggedIn()) {
            // If not logged in redirect to LoginActivity and dont do anything else
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Setup initial HomeFragment and bottom navigation
        loadFragment(new HomeFragment());
        setupBottomNavigation();
        // queue the worker job
        scheduleInventoryCheck();
    }

    // Setup the bottom navigation bar
    private void setupBottomNavigation() {
        bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home) {
                loadFragment(new HomeFragment());
                return true;
            } else if (item.getItemId() == R.id.inventory) {
                loadFragment(new InventoryFragment());
                return true;
            } else if (item.getItemId() == R.id.users) {
                loadFragment(new UsersFragment());
                return true;
            } else {
                return false;
            }
        });
    }

    // Setup the database tables asynchronously
    private class SetupDatabaseTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            dbHelper.getWritableDatabase();
            return null;
        }
    }

    // Setup inventoryCheckRequest worker job and queue it using WorkManager
    private void scheduleInventoryCheck() {
        Constraints constraints = new Constraints.Builder()
                .build();

        // Configure job to run every 15 minutes
        PeriodicWorkRequest inventoryCheckRequest = new PeriodicWorkRequest.Builder(InventoryCheckWorker.class, 15, TimeUnit.MINUTES)  // Runs every 15 minutes
                .setConstraints(constraints)
                .build();

        // Queue the work with WorkManager
        WorkManager.getInstance(this).enqueue(inventoryCheckRequest);
    }

    // Switch between fragments
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    // Check the SharedPreferences file if the user is logged in for routing entry from notifications
    private boolean isLoggedIn() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        return sharedPreferences.getBoolean("IsLoggedIn", false);
    }
}
