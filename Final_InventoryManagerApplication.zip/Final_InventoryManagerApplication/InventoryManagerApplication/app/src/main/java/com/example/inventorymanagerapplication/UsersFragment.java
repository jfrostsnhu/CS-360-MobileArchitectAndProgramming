package com.example.inventorymanagerapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

//     This class facilitates users list and updates to admin status

public class UsersFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private ListView usersListView;
    private SimpleCursorAdapter usersCursorAdapter;
    private EditText searchUsers;
    private ImageButton logoutButton;
    public static final String SHARED_PREFS = "Shared_Prefs";
    public int isAdmin;
    SharedPreferences sharedPreferences;


    // Inflate the layout and initialize the views and assets, set addItem and logout onClick Listeners
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_users, container, false);
        initViews(view);
        setupListViewAdapter();
        new LoadUsersTask().execute();

        // Setup the text watcher for the search input field
        searchUsers.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Execute the filter task as text changes asynchronously
                new FilterUsersTask().execute(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
        // Set onClick listener for logout
        logoutButton.setOnClickListener(v -> logoutUser());

        return view;
    }

    // Initialize variables used for the UI and instantiate dbHelper object
    private void initViews(View view) {
        usersListView = view.findViewById(R.id.users_list_view);
        searchUsers = view.findViewById(R.id.search_users);
        logoutButton = view.findViewById(R.id.logoutUF);
        dbHelper = new DatabaseHelper(getActivity());
    }

    // Set the listView adapter and data bindings for users_list_view
    private void setupListViewAdapter() {
        usersCursorAdapter = new SimpleCursorAdapter(
                getActivity(), R.layout.user_list_item, null,
                new String[]{"first_name", "last_name", "email", "is_admin"},
                new int[]{R.id.first_nameUF, R.id.last_nameUF, R.id.emailUF, R.id.edit_user},0);

        usersCursorAdapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
            // Binding the data to the view
            @Override
            public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
                if (view instanceof ImageButton) {
                    ImageButton editUserButton = (ImageButton) view;
                    isAdmin = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE).getInt("is_admin", 0);

                    int isAdminIndex = cursor.getColumnIndex("is_admin");
                    if (isAdminIndex == -1) {
                        return false; // In case of OutOfBoundsException
                    }
                    // Get the admin status of the user selected in the list view
                    int listUserAdminStatus = cursor.getInt(isAdminIndex);

                    int userIdIndex = cursor.getColumnIndex("_id");
                    if (userIdIndex == -1) {
                        return false; // In case of OutOfBoundsException
                    }
                    int userId = cursor.getInt(userIdIndex);
                    // Set onClick listener for edit_user button, only allow if isAdmin == 1
                    editUserButton.setOnClickListener(v -> {
                        if (isAdmin == 0) {
                            Toast.makeText(getActivity(), "Must be an admin", Toast.LENGTH_SHORT).show();
                        } else {
                            showEditUserDialog(listUserAdminStatus, userId);
                        }
                    });
                    return true;
                }
                return false;
            }
        });
        // Set the adapter with the bound objects and data
        usersListView.setAdapter(usersCursorAdapter);
    }

    // Load the users_list_view asynchronously
    private class LoadUsersTask extends AsyncTask<Void, Void, Cursor> {
        @Override
        protected Cursor doInBackground(Void... voids) {
            return dbHelper.getAllUsers();
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            usersCursorAdapter.changeCursor(cursor);
            usersCursorAdapter.notifyDataSetChanged();
        }
    }

    // Load the users_list_view using search filters asynchronously
    private class FilterUsersTask extends AsyncTask<String, Void, Cursor> {
        @Override
        protected Cursor doInBackground(String... strings) {
            return dbHelper.getFilteredUsers(strings[0]);
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            Cursor oldCursor = usersCursorAdapter.swapCursor(cursor);  // Swap and get old cursor
            usersCursorAdapter.notifyDataSetChanged();
            if (oldCursor != null) {
                oldCursor.close();  // Close the old cursor to prevent memory leaks
            }
        }
    }

    // Log the user out, Update SharedPreferences file, Return to LoginActivity
    private void logoutUser() {
        // Clear session data or any other necessary cleanup
        sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("is_admin");
        editor.putBoolean("IsLoggedIn", false);
        editor.apply();

        // Redirect to LoginActivity
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        getActivity().finish();
    }

    // Create and inflate the edit user dialog and update the is_admin status from adminCheckbox state
    private void showEditUserDialog(int listUserAdminStatus, int userId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_user, null);
        CheckBox adminCheckbox = dialogView.findViewById(R.id.admin_checkbox);

        adminCheckbox.setChecked(listUserAdminStatus == 1);

        builder.setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    boolean setAdmin = adminCheckbox.isChecked(); // Check state of adminCheckbox
                    updateIsAdmin(userId, setAdmin); // Update is_admin value with result
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Call the updateIsAdmin method in dbHelper to update is_admin value
    private void updateIsAdmin(int userId, boolean isAdmin) {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        dbHelper.updateIsAdmin(userId, isAdmin ? 1 : 0);

        new LoadUsersTask().execute(); // Refresh the users list asynchronously
    }
}
