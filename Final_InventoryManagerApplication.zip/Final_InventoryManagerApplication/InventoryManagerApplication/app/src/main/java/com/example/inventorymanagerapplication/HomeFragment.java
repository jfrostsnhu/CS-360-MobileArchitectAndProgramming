package com.example.inventorymanagerapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

/*   This class handles the notifications list in HomeFragment    */
/*              in the inventory manager application              */

public class HomeFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private ImageButton logoutButton;
    private ListView notificationsListView;
    private SimpleCursorAdapter notificationsCursorAdapter;
    public static final String SHARED_PREFS = "Shared_Prefs";
    SharedPreferences sharedPreferences;

    // Inflate the layout and initialize the views and assets, set logout onClick Listener
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        initViews(view);

        /* To underline the notification list header can use a drawable or cast it to SpannableString */
        TextView recent_Notifications = view.findViewById(R.id.notificationsListViewHeader);
        String notifyHeaderText = "Recent Notifications:";
        SpannableString spanNotifyHeader = new SpannableString(notifyHeaderText); //
        spanNotifyHeader.setSpan(new UnderlineSpan(), 0, notifyHeaderText.length(), 0);
        recent_Notifications.setText(spanNotifyHeader);

        setupListView();

        logoutButton.setOnClickListener(v -> logoutUser());

        return view;
    }

    // Initialize variables used for the UI and instantiate dbHelper object
    private void initViews(View view) {
        logoutButton = view.findViewById(R.id.logoutHF);
        notificationsListView = view.findViewById(R.id.notifications_list_view);
        dbHelper = new DatabaseHelper(getActivity());
    }

    // Set the listView adapter and data bindings
    private void setupListView() {
        // Columns from the database that will be used for the UI
        String[] from = new String[]{"skuno", "quantity"};
        // The IDs of the views in the layout to which the data will be bound
        int[] to = new int[]{R.id.skuno_notification, R.id.quantity_notification};

        // Create the adapter from notification_list_item layout
        notificationsCursorAdapter = new SimpleCursorAdapter(getActivity(),
                R.layout.notifications_list_item, null, from, to, 0) {
            // Bind the data to the view
            @Override
            public void bindView(View view, Context context, Cursor cursor) {
                super.bindView(view, context, cursor);

                // Safe checks for column indices to prevent IndexOutOfBoundsException
                int skuNoIndex = cursor.getColumnIndex("skuno");
                int quantityIndex = cursor.getColumnIndex("quantity");
                int isNewIndex = cursor.getColumnIndex("is_new");

                if (skuNoIndex == -1 || quantityIndex == -1 || isNewIndex == -1) {
                    return;
                }

                // If index is valid, get the skuNo, quantity, and is_new values from the cursor
                String skuNo = cursor.getString(skuNoIndex);
                int quantity = cursor.getInt(quantityIndex);
                int isNew = cursor.getInt(isNewIndex);

                // Initialize notications_list_view objects
                TextView skuNoView = view.findViewById(R.id.skuno_notification);
                ImageView bulletView = view.findViewById(R.id.notification_status_bullet);
                TextView quantityView = view.findViewById(R.id.quantity_notification);

                // Set Text for labels, new notificaions are bold with ic_bullet_filled
                skuNoView.setText("Sku No: " + skuNo);
                skuNoView.setTypeface(null, isNew == 1 ? Typeface.BOLD : Typeface.NORMAL);
                quantityView.setText("Quantity: " + quantity);
                quantityView.setTypeface(null, isNew == 1 ? Typeface.BOLD : Typeface.NORMAL);
                bulletView.setImageResource(isNew == 1 ? R.drawable.ic_bullet_filled : R.drawable.ic_bullet_unfilled);
            }
        };

        // Set the adapter with the bound objects and data
        notificationsListView.setAdapter(notificationsCursorAdapter);
        // onClick listener for marking notifications as read
        notificationsListView.setOnItemClickListener((adapterView, view, position, id) -> {
            Cursor cursor = (Cursor) notificationsCursorAdapter.getItem(position); // Cursor contains item matching clicked position
            int isNewIndex = cursor.getColumnIndex("is_new");
            int skunoIndex = cursor.getColumnIndex("skuno");
            // Return if data is not new or IndexOutOfBounds
            if (skunoIndex == -1 || isNewIndex == -1 || cursor.getInt(isNewIndex) == 0) {
                return;
            }
            // Pass skuno to dbHelper to set is_new == 0
            String skuno = cursor.getString(skunoIndex);
            dbHelper.markAsRead(skuno);
            loadNotifications();  // Refresh the notifications_list_view TODO: Move to AsyncTask if time permits
        });
        // Load the notifications_list_view
        loadNotifications();
    }

    // Get all notifications from dbHelper and update the cursor
    private void loadNotifications() {
        Cursor cursor = dbHelper.getAllNotifications();
        notificationsCursorAdapter.changeCursor(cursor);
        notificationsCursorAdapter.notifyDataSetChanged();
    }

    // Log the user out, Update SharedPreferences file, Return to LoginActivity
    private void logoutUser() {
        // Update SharedPreferences to remove is_admin and flip isLoggedIn boolean
        sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("is_admin"); // In case a non-admin user logs in next from the device
        editor.putBoolean("IsLoggedIn", false); // Used for entry from a notification
        editor.apply();

        // Redirect to LoginActivity
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        getActivity().finish();
    }
}
