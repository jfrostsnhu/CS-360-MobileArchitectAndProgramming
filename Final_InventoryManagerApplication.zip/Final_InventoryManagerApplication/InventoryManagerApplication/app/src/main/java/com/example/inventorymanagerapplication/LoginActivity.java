package com.example.inventorymanagerapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/*     This class facilitates login to the         */
/*      the inventory manager application          */

public class LoginActivity extends AppCompatActivity {

    private EditText emailLoginText, passwordLoginText;
    private Button loginButton, createAccountButton;
    private DatabaseHelper dbHelper;

    public static final String SHARED_PREFS = "Shared_Prefs";
    public int isAdmin;

    SharedPreferences sharedPreferences;

    // Inflate the layout and initialize the views and assets, set addItem and logout onClick Listeners
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailLoginText = findViewById(R.id.emailLA);
        passwordLoginText = findViewById(R.id.passwordLA);
        loginButton = findViewById(R.id.loginButtonLA);
        createAccountButton = findViewById(R.id.createAccountButtonLA);
        dbHelper = new DatabaseHelper(this);

        loginButton.setEnabled(false); // Disable the login button while fields are empty

        // Instantiate Listener for checking empty input fields
        TextWatcher loginTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                checkFieldsForEmptyValues();
            }
        };

        emailLoginText.addTextChangedListener(loginTextWatcher);
        passwordLoginText.addTextChangedListener(loginTextWatcher);
        // Set onClick Listener for login button to validate email/password and isAdmin value
        loginButton.setOnClickListener(v -> {
            String email = emailLoginText.getText().toString();
            String password = passwordLoginText.getText().toString();
            try (Cursor cursor = dbHelper.validateUser(email, password)) {
                if (cursor.moveToFirst()) {
                    int adminIndex = cursor.getColumnIndex("is_admin");
                    if (adminIndex != -1) { // Check if user is an admin
                        isAdmin = cursor.getInt(adminIndex);

                        // Store isAdmin in SharedPreferences for later use
                        sharedPreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt("is_admin", isAdmin);
                        editor.putBoolean("IsLoggedIn", true); // IsLoggedIn used for entry from notifications
                        editor.apply();

                        // Proceed to MainActivity
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else { // toast for troubleshooting
                        Toast.makeText(LoginActivity.this, "Failed to retrieve is_admin value", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set onClick listener for create account button to start CreateAccountActivity
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }

    // If input fields are not empty enable the login button
    private void checkFieldsForEmptyValues() {
        String email = emailLoginText.getText().toString().trim();
        String password = passwordLoginText.getText().toString().trim();
        loginButton.setEnabled(!email.isEmpty() && !password.isEmpty());
    }
}
