package com.example.inventorymanagerapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*   This class facilitates database transactions    */
/*       in the inventory manager application        */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryManager.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // When onCreate() is called create the tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE users (" +
                        "user_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "first_name TEXT," +
                        "last_name TEXT," +
                        "email TEXT UNIQUE," +
                        "password TEXT," +
                        "is_admin INTEGER DEFAULT 0)"
        );
        db.execSQL(
                "CREATE TABLE items (" +
                        "item_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "skuno TEXT," +
                        "description TEXT," +
                        "quantity INTEGER)"
        );
        db.execSQL(
                "CREATE TABLE notifications (" +
                        "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "skuno TEXT," +
                        "quantity INTEGER," +
                        "is_new INTEGER DEFAULT 0)"
        );
    }

    // When onUpgrade() called by change in db version drop and recreate tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS items");
        db.execSQL("DROP TABLE IF EXISTS notifications");
        onCreate(db);
    }

    // Insert new user values from CreateAccountActivity
    public boolean addUser(String firstName, String lastName, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("first_name", firstName);
        values.put("last_name", lastName);
        values.put("email", email);
        values.put("password", password);
        values.put("is_admin", 1);
        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    // Validate email and password combination from LoginActivity
    public Cursor validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("users",
                new String[] {"user_id", "is_admin"},
                "email = ? AND password = ?",
                new String[] {email, password}, null, null, null);
        return cursor;
    }

    // Get a list of all users for user_list_view
    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("users",
                new String[] {"user_id AS _id", "first_name", "last_name", "email", "is_admin"},
                null, null, null, null, "first_name ASC, last_name ASC");
    }

    // Get a list of all users for user_list_view matching search filter
    public Cursor getFilteredUsers(String filter) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("users",
                new String[] {"user_id AS _id", "first_name", "last_name", "email", "is_admin"},
                "first_name LIKE ? OR last_name LIKE ? OR email LIKE ?",
                new String[] {"%" + filter + "%", "%" + filter + "%", "%" + filter + "%"},
                null, null, "first_name ASC, last_name ASC");
    }

    // Update is_admin value from adminCheckbox in UserFragment
    public void updateIsAdmin(int userId, int isAdmin) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("is_admin", isAdmin);
        db.update("users", values, "user_id = ?", new String[] { String.valueOf(userId)});
        db.close();
    }

    // Get a list of all items for item_list_view
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("items",
                new String[] {"item_id AS _id", "skuno", "description", "quantity"},
                null, null, null, null, "skuno ASC");
    }

    // Get a list of all items for item_list_view that matches search filter
    public Cursor getFilteredItems(String filter) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("items",
                new String[] {"item_id AS _id", "skuno", "description", "quantity"},
                "skuno LIKE ? OR description LIKE ?",
                new String[] {"%" + filter + "%", "%" + filter + "%"},
                null, null, "skuno ASC");
    }

    // Update items quantity from qtyEditText in InventoryFragment
    public void updateQuantity(int itemId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);
        int rowsAffected = db.update("items", values, "item_id = ?", new String[]{String.valueOf(itemId)});
        db.close();
    }

    // Insert item to items with values from addItemDialog in InventoryFragment
    public long addItem(String skuno, String description, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if skuno or description is empty
        if (skuno == null || skuno.trim().isEmpty() || description == null || description.trim().isEmpty()) {
            db.close();
            return -1;  // Return -1 to indicate failure due to invalid input
        }

        // Check if the item with the same skuno already exists
        Cursor cursor = db.query("items", new String[]{"item_id"},
                "skuno = ?", new String[]{skuno},
                null, null, null);

        // If cursor has a count > 0 the item exists
        if (cursor.getCount() > 0) {
            // Close cursor and database before returning
            cursor.close();
            db.close();
            // Return -1 to generate failure toast
            return -1;
        }
        cursor.close(); // Close cursor

        // If the skuno does not exist and inputs are valid insert the item
        ContentValues values = new ContentValues();
        values.put("skuno", skuno);
        values.put("description", description);
        values.put("quantity", quantity);
        long result = db.insert("items", null, values);
        db.close();
        return result;  // On success return item_id, on failure return -1 for toast
    }

    // Delete item from items using item_id from deleteItemDialog
    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete("items", "item_id = ?", new String[]{String.valueOf(itemId)});
        db.close();
        return rowsDeleted > 0;
    }

    // Insert notification to notifications
    public void addNotification(String skuno, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if a notification for this skuno already exists
        Cursor cursor = db.query("notifications",
                new String[]{"_id"},
                "skuno = ?",
                new String[]{skuno},
                null, null, null);

        boolean exists = cursor.getCount() > 0; // if skuno is in notifications cursor will be > 0
        cursor.close(); // Close cursor

        if (exists) {
            // If the notification already exists update the existing record with the new quantity
            ContentValues values = new ContentValues();
            values.put("quantity", quantity);
            int rowsAffected = db.update("notifications", values, "skuno = ?", new String[]{skuno});
            db.close();
        } else {
            // If the notification doesn't exist insert a new record
            ContentValues values = new ContentValues();
            values.put("skuno", skuno);
            values.put("quantity", quantity);
            long result = db.insert("notifications", null, values);
            db.close();
        }
    }

    // Delete notification from notifications
    public void removeNotification(String skuno) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("notifications", "skuno = ?", new String[] { skuno });
        db.close();
    }

    /*      Get a list of items for creating notifications for InventoryCheckWorker.    */
    /*                 Takes a threshold from InventoryCheckWorker                      */
    public Cursor getLowStockItems(int threshold) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT skuno, quantity FROM items WHERE quantity < ?", new String[] { String.valueOf(threshold) });
    }

    // Check if item is still low stock. Takes skuno and returns items quantity.
    public int lowStockRecheck(String skuno) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Changed to select the quantity where skuno matches.
        Cursor cursor = db.rawQuery("SELECT quantity FROM items WHERE skuno = ?", new String[] { skuno });

        if (!cursor.moveToFirst()) { // If the cursor is empty the item does not exist
            cursor.close();
            return -1;  // Return -1 to indicate that the item does not exist in the items table
        }

        int quantityIndex = cursor.getColumnIndex("quantity");
        if (quantityIndex == -1) {
            cursor.close();
            return -1;  // Return -1 in case of a column index error
        }

        int quantity = cursor.getInt(quantityIndex);
        cursor.close();
        return quantity;
    }

    // Get a list of notifications for notifications_list_view
    public Cursor getAllNotifications() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM notifications", null);
    }

    // Check if notification for a skuno already exists
    public boolean notificationExists(String skuno, int quantity) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("notifications",
                new String[] {"_id"},
                "skuno = ? AND quantity = ?",
                new String[] {skuno, String.valueOf(quantity)},
                null, null, null);

        boolean exists = cursor.getCount() > 0; // If cursor > 0 then skuno is in notifications
        cursor.close();
        return exists;
    }

    // Set is_new to false when notification is clicked. Called from HomeFragment.
    public void markAsRead(String skuno) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("is_new", 0);  // Set is_new to false
        db.update("notifications", values, "skuno = ?", new String[]{skuno});
        db.close();
    }
}
