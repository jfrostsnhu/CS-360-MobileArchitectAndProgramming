package com.example.inventorymanagerapplication;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

//   This class facilitates requesting for SMS and POST notifications permissions

public class PermissionsRequestActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 1;
    public static final String SHARED_PREFS = "Shared_Prefs";

    /*     Create the view and setup the listeners if the user has not been
         prompted for permissions previously, if they have skip to LoginActivity   */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions_request);

        // Check if SMS/POST permissions status has already been set
        if (hasSetSmsPermission()) {
            // Retrieve the current status of SMS/POST permissions
            boolean isPermissionGranted = getPermissionStatus();
            proceedToLogin(isPermissionGranted); // Proceed to LoginActivity
        } else {
            setupListeners(); // Set up listeners to handle permission requests
        }
    }

    /*     If the user has not granted SMS or POST notifications permissions, requestPermissions
         otherwise proceed to LoginActivity   */
    private void requestPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.SEND_SMS);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        } else {
            savePermissionStatus(true); // Save permissions status in SharedPreferences
            proceedToLogin(true);
        }
    }

    //
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allPermissionsGranted = true;
            for (int result : grantResults) { // Loop through permissions results
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break; // If there are not more results break the loop
                }
            }
            savePermissionStatus(allPermissionsGranted); // Save permissions status in SharedPreferences
            proceedToLogin(allPermissionsGranted); // Proceed to LoginActivity
        }
    }

    // When permissions are granted, status is stored in SharedPreferences for later use
    private void savePermissionStatus(boolean granted) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("sms_permission_granted", granted);
        editor.apply();
    }

    // Get the permissions status from SharedPreferences
    private boolean getPermissionStatus() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        return sharedPreferences.getBoolean("sms_permission_granted", false); // Default to false if not found
    }

    // Check for sms_permission_granted value to know if PermissionsRequestActivity needs to start
    private boolean hasSetSmsPermission() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        return sharedPreferences.contains("sms_permission_granted");
    }

    // Set onclick listeners for Request Permissions and Cancel buttons
    private void setupListeners() {
        findViewById(R.id.btnRequestPermissionPRA).setOnClickListener(v -> requestPermissions()); // Trigger the request
        findViewById(R.id.btnCancelPRA).setOnClickListener(v -> proceedToLogin(false)); // Skip and start LoginActivity
    }

    // If the user has cancelled the PermissionsRequestActivity dialog or has previously been prompted
    // PermissionsRequestActivity is skipped and LoginActivity is started
    private void proceedToLogin(boolean granted) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}

