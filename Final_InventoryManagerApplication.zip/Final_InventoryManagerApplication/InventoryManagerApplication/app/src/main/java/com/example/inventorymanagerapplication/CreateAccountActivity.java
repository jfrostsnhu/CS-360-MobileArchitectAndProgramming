package com.example.inventorymanagerapplication;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/* This class facilitates creation of a new account  */
/*       in the inventory manager application        */


public class CreateAccountActivity extends AppCompatActivity {

    private EditText emailCAText, passwordCAText, confirmPasswordCAText, firstNameCAText, lastNameCAText;
    private Button createAccountButtonCA;
    private DatabaseHelper dbHelper;

    // When onCreate() is called set the view and bind the text fields

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        emailCAText = findViewById(R.id.emailCAText);
        passwordCAText = findViewById(R.id.passwordCAText);
        confirmPasswordCAText = findViewById(R.id.confirmPasswordCAText);
        firstNameCAText = findViewById(R.id.firstNameCAText);
        lastNameCAText = findViewById(R.id.lastNameCAText);
        createAccountButtonCA = findViewById(R.id.createAccountButtonCA);
        Button cancelButtonCA = findViewById(R.id.cancelButtonCA);
        dbHelper = new DatabaseHelper(this);
        // Create Account button is disabled until fields are filled
        createAccountButtonCA.setEnabled(false);

        // Listener object for all the input fields calls method to enable createAccountButtonCA
        TextWatcher createAccountTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                checkFieldsForEmptyValues();
            }
        };
        // Adding the listener to the input fields
        emailCAText.addTextChangedListener(createAccountTextWatcher);
        passwordCAText.addTextChangedListener(createAccountTextWatcher);
        confirmPasswordCAText.addTextChangedListener(createAccountTextWatcher);
        firstNameCAText.addTextChangedListener(createAccountTextWatcher);
        lastNameCAText.addTextChangedListener(createAccountTextWatcher);

        // When create account is clicked, call createAccount()
        createAccountButtonCA.setOnClickListener(v -> {
            createAccount();
        });
        // When cancel is clicked, return to previous activity
        cancelButtonCA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // Check input fields for a value and enable the create account button
    private void checkFieldsForEmptyValues() {
        String email = emailCAText.getText().toString().trim();
        String password = passwordCAText.getText().toString().trim();
        String confirmPassword = confirmPasswordCAText.getText().toString().trim();
        String firstName = firstNameCAText.getText().toString().trim();
        String lastName = lastNameCAText.getText().toString().trim();

        // Enable the button only if all fields are not empty
        createAccountButtonCA.setEnabled(!email.isEmpty() && !password.isEmpty() &&
                !confirmPassword.isEmpty() && !firstName.isEmpty() &&
                !lastName.isEmpty());
    }

    // Create account using AsyncTask
    private void createAccount() {
        String firstName = firstNameCAText.getText().toString().trim();
        String lastName = lastNameCAText.getText().toString().trim();
        String email = emailCAText.getText().toString().trim();
        String password = passwordCAText.getText().toString().trim();
        String confirmPassword = confirmPasswordCAText.getText().toString().trim();
        // Confirm passwords match
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Execute AsyncTask to add user to database using form data
        new AddUserTask().execute(firstName, lastName, email, password);
    }

    // AsyncTask to call addUser method
    private class AddUserTask extends AsyncTask<String, Void, Boolean> {
        protected Boolean doInBackground(String... params) {
            return dbHelper.addUser(params[0], params[1], params[2], params[3]); // call addUser from DatabaseHelper
        }

        // Toast on success/fail
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(CreateAccountActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(CreateAccountActivity.this, "Account Creation Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
